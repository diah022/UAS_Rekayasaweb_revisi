<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Book_adm extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
		$load_model = array('Book_model'=>'BM');
        $this->load->model($load_model);        
    }
 
    public function ajax_list()
	{
		$list = $this->BD->get_datatables();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $books) {
			$no++;
			$row = array();
			$row[] = $books->book_id;
			$row[] = $books->book_isbn;
			$row[] = $books->book_title;
			$row[] = $books->book_author;
			//add html for action
			$row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_book('."'".$books->book_id."'".')"><i class="glyphicon glyphicon-pencil"></i> Edit</a>
					  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_book('."'".$books->book_id."'".')"><i class="glyphicon glyphicon-trash"></i> Delete</a>';
		
			$data[] = $row;
		}

		$output = array(
						"draw" => $_POST['draw'],
						"recordsTotal" => $this->BM->count_all(),
						"recordsFiltered" => $this->BM->count_filtered(),
						"data" => $data,
				);
		//output to json format
		echo json_encode($output);
	}


    public function ajax_edit($id)
	{
		$data = $this->BM->get_by_id($id);		
		echo json_encode($data);
	}

	public function ajax_add()
	{
		$this->_validate();
		$data = array(
				'book_title' => $this->input->post('book_title'),
				'book_author' => $this->input->post('book_author'),
				'book_isbn' => $this->input->post('book_isbn')
			);
		$insert = $this->BM->save($data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_update()
	{
		$this->_validate();
		$data = array(
				'book_title' => $this->input->post('book_title'),
				'book_author' => $this->input->post('book_author'),
				'book_isbn' => $this->input->post('book_isbn')
			);
		$this->BM->update(array('book_id' => $this->input->post('id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function ajax_delete($id)
	{
		$this->BM->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}


	private function _validate()
	{
		$data = array();
		$data['error_string'] = array();
		$data['inputerror'] = array();
		$data['status'] = TRUE;

		if($this->input->post('book_title') == '')
		{
			$data['inputerror'][] = 'book_title';
			$data['error_string'][] = 'Book Title is required';
			$data['status'] = FALSE;
		}

		if($this->input->post('book_author') == '')
		{
			$data['inputerror'][] = 'book_author';
			$data['error_string'][] = 'Author is required';
			$data['status'] = FALSE;
		}
		
		if($data['status'] === FALSE)
		{
			echo json_encode($data);
			exit();
		}
	}
        
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */