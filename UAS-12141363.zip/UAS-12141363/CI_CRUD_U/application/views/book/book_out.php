<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('maintemp/header');
//$this->load->view('sidebar');
?>
<!--<div id="content">-->
<div class="container">
   
            <div class="row">
                <div class="box">
                    <div class="col-lg-12">
                        <h1>BOOKS LIST<hr /></h1>
                        <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
							<th>Book ID</th>
							<th>Book ISBN</th>
							<th>Book Title</th>
							<th>Book Author</th>

                        </thead>
                        <?php
                                $no=1;
                                foreach($books as $b){
                                        echo "<tr><td align=center>$no.</td><td>$b->book_id</td><td>$b->book_isbn</td><td>$b->book_title</td><td>$b->book_author</td></tr>";
                                        $no++;	}
                        ?>
                        </table>
                    </div>
                </div>
            </div>
    <!-- /.container -->
</div>
<?php
$this->load->view('maintemp/footer');
?>
<div style="clear: both;"></div>