<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Book_data extends CI_Model{
	function tampil_data(){
		return $this->db->get('books');
	}
}
?>